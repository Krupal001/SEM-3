<?php
    $cities=array(
        "ram"=>"Nadiad",
        "shyam"=>"Mumbai",
        "janak"=>"goa",
        "magan"=>"surat",
        "param"=>"diu");
    
    foreach($cities as $key=>$value){
        echo $key."=>".$value."<br>";
    }
?>